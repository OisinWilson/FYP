//Author : Oisin Wilson (C00213826)
// This is used to pass the scanned product name back to a typable compnent in the input

export default dataPass = {
    "MealName": "Scan Barcode or Type what you ate here!",
    "MealCode": 0
  };