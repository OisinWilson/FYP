//Author : Oisin Wilson (C00213826)
// This is the navigation point for the app with all of the screen codes

import { createStackNavigator } from 'react-navigation-stack';
import HomeScreen from './HomeScreen';
import CalendarScreen from './CalendarView';
import CircleViewManager from './CircleViewManager';
import BranchView from './BranchView';
import PiView from './PiView';
import InputScreen from './InputManager';
import ScanScreen from './ScanView';

const AppNavigator = createStackNavigator({
  Home: { screen: HomeScreen, navigationOptions: {header: null} },
  Calendar: { screen: CalendarScreen, navigationOptions: {header: null}},
  SCV: {screen: CircleViewManager},
  BV: {screen: BranchView},
  PI: {screen:PiView},
  INPUT: {screen: InputScreen, navigationOptions: {header: null}},
  SCAN: {screen: ScanScreen, navigationOptions: {header: null},},
});

export default  AppNavigator;