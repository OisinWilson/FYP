//Author : Oisin Wilson (C00213826)
// This is home display for the app 

import * as React from 'react';
import { StyleSheet, Text, View, Button, Alert, Platform, Image, TouchableOpacity } from 'react-native';
import styles from './Styles';
import CircleViewManager from './CircleViewManager';
import Slider from "react-native-slider";
import PiDATA from "./PiViewManager";

import DatabaseManager from "./DataBaseManager";

export default class HomeScreen extends React.Component {
  constructor(props){
    super(props);
    
    this.state = {
      count: 0,
      value: 0,
      gluten:"Yes"
    };
  }

    componentDidMount(){
      this.focusListener = this.props.navigation.addListener('didFocus', () => {
        this.setState({ count: this.state.count + 1 });
      });


    }

    render() {
      const {navigate} = this.props.navigation;
     
      return(
        
        <View style={styles.container} >

          {this.state.value == 0 ? 
          <View style = {[{top:-50}]}>
              <CircleViewManager/>
          </View>
          : null}
          

          {this.state.value == 1 ? 
          <View style = {[{top:-50}]}>
              <PiDATA/>
          </View>
          : null}



        <View style={[{
                      position:'absolute',
                      bottom:80,
                      flex: 1,
                      width: 300,
                      marginLeft: 10,
                      marginRight: 10,
                      alignItems: "stretch",
                      justifyContent: "center" }]}>
          <Slider
              value={this.state.value}
              step={1}
              minimumValue={0}
              maximumValue={1}
              onValueChange={value => this.setState({ value })}
            />
           
          </View>

          {BottomBar(1, navigate) }
        
        </View>
      
      );
    }
  }

//<Button title="Input" color= "#ECA37A" onPress={() => navigate('INPUT')}/>
    
/*
 <Text>
              Value: {this.state.value}
            </Text>
*/


    function BottomBar(selector, navigate) {
      return( 
        <View style={styles.bottomView}>
    
                    { selector == 2 ? <Image style = {styles.calenderActive} source={require('./calendar.png')}/> 
                                                    : <Image style = {styles.calenderInactive} source={require('./calendar.png')}/>}
    
                    { selector == 1 ? <Image style = {styles.homeActive} source={require('./house.png')}/> 
                                                    : <Image style = {styles.homeInactive}source={require('./house.png')}/>}
    
                    { selector == 0 ? <Image style = {styles.InputActive} source={require('./input.png')}/> 
                                                    : <Image style = {styles.InputInactive} source={require('./input.png')}/>}
    
                    <TouchableOpacity style={styles.BottomTouchLeft} onPress={ () => navigate("INPUT") }/>
    
                    <TouchableOpacity style={styles.BottomTouchMid} onPress={ () => navigate("Home")} />
    
                    <TouchableOpacity style={styles.BottomTouchRight} onPress={ () => navigate("Calendar")}/>
        </View>
        )
    };




