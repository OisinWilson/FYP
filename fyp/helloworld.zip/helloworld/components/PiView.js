//Author : Oisin Wilson (C00213826)

import * as React from 'react';
import * as Native from 'react-native';
import * as Chart from 'victory-native';
import DatabaseManager from './DataBaseManager';
import { element } from 'prop-types';

let m_dataStack =[0,0,0,0]; //symptoms, gluten Pos, gluten Neg, no symptoms
let m_dateStack = [];
let finalData = [0,0,0,0];
let progressBarX = 62;
let progressBarY = 220;

export default class PiView extends React.Component{
  constructor(props){
    super(props);
    this.state = {
      DisplayOne: 0
    };
  }



  circleStyle = function(x, y, color) {
    return {
        zIndex : 1,
        width: smallCircleRadius * 2,
        height: smallCircleRadius * 2,
        borderRadius: 100/2,
        backgroundColor: color,
        position: 'absolute', 
        left: x,
        top: y
    }
  }

  render() {

    let maxDateValue = new Date().getDate();

    let stack = this.props.InfoList;

    m_dataStack =[0,0,0,0];
    finalData = [0,0,0,0]
    
  
    stack.forEach(element => {
      switch (element) {
        case 0:
          m_dataStack[3]++;
          break;
        case 1:
          m_dataStack[1]++;
          break;
        case 2:
          m_dataStack[2]++;
          break;
        case 3:
          m_dataStack[0]++;
          break;
          
        default:
          break;
      }
    })

    for(var i = 0; i < 4; i++)
    {
      finalData[i] = (m_dataStack[i] / maxDateValue) * 100;
    }



    return (
      <Native.View style={styles.MainContainer}>

    
        <Chart.VictoryPie
           labelRadius={({ innerRadius }) => innerRadius + 5 }
           radius={({ datum }) => 50 + datum.y * 2}
           innerRadius={50}
           style={{ labels: { fill: "white", fontSize: 20, fontWeight: "bold" } }}
        colorScale={["blue", "red", "green", "grey" ]}
            data={[
                {x:m_dataStack[0], y: finalData[0], lable:"Symptoms Only" },
                {x:m_dataStack[1], y: finalData[1] , lable:"Gluten"},
                {x:m_dataStack[2], y: finalData[2], lable:"No Gluten" },
                {x:m_dataStack[3], y: finalData[3] , lable:"No Entrys"},
            ]}
            />



                <Native.View style={{width: 100, height: 50, position:"absolute", top: progressBarY + 275, left: progressBarX + 30}}>
                  <Native.Text style={{ fontSize: 18, textAlign: 'center' }}>{ m_dataStack[2] == 1?  m_dataStack[2] + " Day\nNo Gluten" : m_dataStack[2] + " Day's\nNo Gluten"}</Native.Text>
                  <Native.View style={circleStyle(-25, 10, "green")}/>
                </Native.View>

                <Native.View style={{width: 100, height: 50, position:"absolute", top: progressBarY + 275, left: progressBarX + 180}}>
                  <Native.Text style={{ fontSize: 18, textAlign: 'center' }}>{ m_dataStack[1] == 1? m_dataStack[1] + " Day\nGluten" : m_dataStack[1] + " Day's\nGluten"}</Native.Text>
                  <Native.View style={circleStyle(-25, 10,"red")}/>
                </Native.View>

                <Native.View style={{width: 100, height: 50, position:"absolute", top: progressBarY + 350, left: progressBarX + 180}}>
                  <Native.Text style={{ fontSize: 18, textAlign: 'center' }}>{ m_dataStack[3] == 1? m_dataStack[3] + " Day\nNo Entry" : m_dataStack[3] + " Day's\nNo Entry"}</Native.Text>
                  <Native.View style={circleStyle(-25, 10,"grey")}/>
                </Native.View>

               
                <Native.View style={{width: 100, height: 50, position:"absolute", top: progressBarY + 350, left: progressBarX + 30}}>
                  <Native.Text style={{ fontSize: 18, textAlign: 'center' }}>{ m_dataStack[0] == 1? m_dataStack[0] + " Day\nSymptoms Only" : m_dataStack[0] + " Day's\nSymptoms Only"}</Native.Text>
                  <Native.View style={circleStyle(-25, 10,"blue")}/>
                </Native.View>


      </Native.View>
    );
  }
}

const styles = Native.StyleSheet.create({
    MainContainer:
    {
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#FFFFFF',
      top: -100
    },   
});