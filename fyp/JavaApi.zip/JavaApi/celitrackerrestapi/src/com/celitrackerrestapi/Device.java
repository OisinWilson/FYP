package com.celitrackerrestapi;

/**
* The Device class maintains the a users Celi Tracker App ongoing usage. 
* It only stores the Device Token and the last time data was entered into
* the APP. This information is used to Push Notifications to the user 
* whenever too long a gap of time elapses between entries. 
*
* @author  Oisin Wilson
* @version 1.0
* @since   2020-03-25
*/
public class Device {
	String token; 
	long time;
	
	/**
	 * The Device constructor takes the two key attributes to allow 
	 * the system to identity users who leaves too much of a gap between 
	 * entries into Celi Tracker App.
	 * 
	 * @param token Device Token used to send Notifications to the User. 
	 * @param time The last time the user entered data into the 
	 *             Celi Tracker App
	 */
	public Device(String token, long time) {
		this.token = token;
		this.time = time;
	}
	
	/**
	 * A getter method to the Device token.
	 *  
	 * @return String token value. 
	 */	
	public String getToken() {
		return token;
	}
	
	/**
	 * A setter method for the users the Device token.
	 *  
	 * @param String token Device Token used to send Notifications 
	 *        to the User.  
	 * @return Nothing. 
	 */		
	public void setToken(String token) {
		this.token = token;
	}
	
	/**
	 * A getter method for the last time the user entered data into the 
	 *             Celi Tracker App.
	 *  
	 * @return long The last time the user entered data into the 
	 *             Celi Tracker App.  
	 */			
	public long getTime() {
		return time;
	}

	/**
	 * A setter method for the last time the user entered data into the 
	 *             Celi Tracker App.
	 *  
	 * @param long the last time the user updated the Celi Tracker App.
	 * @return Nothing. 
	 */			
	public void setTime(long time) {
		this.time = time;
	} 
}
