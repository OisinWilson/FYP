package com.celitrackerrestapi;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONObject;

/**
 * The NotificationManager is a java Thread is like a virtual CPU that 
 * can execute your Java code inside the current application. From 
 * inside REST API the NotificationManager thread is created once 
 * since its a static variable. When the NotificationManager is started 
 * it executes in parallel to the REST API.  
 * 
 * @author  Oisin Wilson
 * @version 1.0
 * @since   2020-03-25 
 */
public class NotificationManager extends Thread
{ 
	/**
	 * Constructor which is called once and starts this thread off and 
	 * allows it to run in parallel 
	 */
	public NotificationManager() {
		start(); // start thread.
	}
	
	/**
	 * this stores how many seconds until a device should be sent a
	 * notification. 
	 */
	private int secondsBeforeNotifications = 86400; // one day
	
	/**
	 * This is a public getter method which is synchronized that returns 
	 * the current value of secondsBeforeNotifications. Using synchronized
	 * on the method ensures nothing unusual happens when the system is 
	 * running in parallel. 
	 * 
	 * @return int seconds before notifications
	 */
	public synchronized int getSecondsBeforeNotifications() {
		return secondsBeforeNotifications;
	}

	/**
	 * This is a public setter method which is synchronized that allows 
	 * the setting of the secondsBeforeNotifications variable. Using 
	 * synchronized on the method ensures nothing unusual happens when 
	 * the system is running in parallel. 
	 * 
	 * @param int new seconds before notifications value
	 * @return Nothing. 
	 */
	public synchronized void setSecondsBeforeNotifications(int secondsBeforeNotifications) {
		this.secondsBeforeNotifications = secondsBeforeNotifications;
	}
	
	/**
	 * This is an ArrayList of known Devices that are managed by the class. 
	 */
	private ArrayList<Device> devices = new ArrayList<Device>();

	/**
	 * This is a getter method for all known devices.
	 * @return ArrayList<Device> Array of devices. 
	 */
    public ArrayList<Device> getDevices() {
		return devices;
	}
    
    /**
	 * This method adds a new device to the array of devices. 
	 * @param Device a device object. 
	 * @return Nothing  
	 */    
    public void addDevice(Device device) {
		devices.add(device);
	}
      
    
    @Override
    /**
     * The Java @Override annotation indicates that the child class method is 
     * over-writing its base class method. It extracts a warning from the 
     * compiler if the annotated method doesn't actually override anything
     */
    
    /**
     *  This method id called in parallel to the main thread and allows for 
     *  checks of known devices to see have they been updated recently. If
     *  any device hasnt been updated this device will be send a push notification 
     *  reminding the user to update the diet journal. 
     *  @return Nothing.
     */
    public void run()
    {
    	while(true) { // thread runs forever. 
    		try {
    			Thread.sleep(1000); // sleeps the thread for 1 second. 
    			
    			// get the current time in milliseconds 
    			long currentTime = System.currentTimeMillis();
    			
    			/**
    			 *  sends the the current time in milliseconds to the 
    			 *  method to allow it to check to see if any devices 
    			 *  have been updated. 
    			 */
    			sendRequiredPushNotifications(currentTime);
    		} catch (InterruptedException e) {
    			e.printStackTrace();
    		} 
    	}
    }

    /**
     * This private method checks all known devices against the current time and 
     * sees does any notifications needs to be sent. 
     * @param long the current time.
     * @return Nothing.
     */
	private void sendRequiredPushNotifications(long currentTime)
	{
		// an empty array of devices that need to be notified. 
		ArrayList<String> tokens = new ArrayList<String>();
		
		/**
		 * the time to be added on the last time a device has been updated to see if
		 * it needs to be notified. 
		 */
        long addonTime = (getSecondsBeforeNotifications()*1000);
        
        /**
         *  synchronized block to ensure nothing usual happens to the devices as
         *  they are being processed.
         */
		synchronized(this){ 
			Iterator<Device> d = devices.iterator(); 
			while (d.hasNext()) { 
				Device device = d.next(); // get each know device
				if ( currentTime > (device.getTime() + addonTime )) {
					/**
					 *  this device hasnt been updated for a while and requires a 
					 *  notification to be sent to it. So add it to the list which 
					 *  notifications will be sent to it.  
					 */ 
					tokens.add(device.getToken());
					// update the date on the device so a device doesnt get too many notifcations. 
					device.setTime( (currentTime + addonTime )); 
				}
			}
		}
		
		Iterator<String> t = tokens.iterator(); 
		while (t.hasNext()) { 
			String token = t.next(); // get each device that needs a notification sent to it. 
			// isoPushNotification(token);
			andriodPushNotification(token);
		}
	}

	
	/**
	 * The method andriodPushNotification uses Googles Firebase Cloud Messaging to send
	 * messages to android Apps by means on App notifications. The Firebase Cloud Messaging 
	 * is a cross-platform messaging solution that reliably send messages at no cost. For
	 * more info check out: https://firebase.google.com/docs/cloud-messaging
	 * 
	 * The method uses Apache HTTP client and an authorization signed key to push messaging. 
	 * @param String this is the token to send the message to the registered device. 
	 * @return Nothing
	 */
    private void andriodPushNotification(String token) 
    {
    	HttpClient client = HttpClientBuilder.create().build();
    	try {
    	  	HttpPost post = new HttpPost("https://fcm.googleapis.com/fcm/send");
        	post.setHeader("Content-type", "application/json");
        	post.setHeader("Authorization", "key=AAAAdeLdUtU:APA91bEnlBiiWjXKgI4clbXRmljitGroMM6XKqmb3crOuO4hkzHmxUf5YMZVj2251Zgz3yoUnP1vXAknzldSbRS6X4z90g9L6y6lynehoWABFUPp08_LnvDGxqi0okPX5SI8PlvzJjCq");

        	JSONObject message = new JSONObject();
        	message.put("to", token);
        	message.put("priority", "high");
 
        	JSONObject notification = new JSONObject();
        	notification.put("title", "Celi-Tracker");
        	notification.put("body", "You havent entered your dietary intake for a while.");

        	message.put("notification", notification);

        	post.setEntity(new StringEntity(message.toString(), "UTF-8"));
        	HttpResponse response = client.execute(post);
        	
        	System.out.println(response);
        	System.out.println(message);    	
    	} catch (Exception ex) {	
    		System.out.println(ex.getMessage());
    	} 
      }
	
	/**
	 * to be documented for android. 
	 * @param command
	 */
	
    private void isoPushNotification(String token) 
    {
		String command = "curl -v -d '{\"aps\":{\"alert\": {\"title\": \"Celi-Tracker\", \"body\": \"You havent entered your dietary intake for a while.\"},\"sound\":\"default\"}, \"data\": \"some custom data\"}' -H \"apns-topic:org.reactjs.native.wilson.PushApp\" -H \"apns-expiration: 1\"  -H \"apns-priority: 10\" --http2 --cert /Users/kwilsonie/Documents/newcert.pem  https://api.development.push.apple.com/3/device/" 
				+ token; 
        ProcessBuilder processBuilder = new ProcessBuilder();
        processBuilder.command("bash", "-c", command);
        try {
            Process process = processBuilder.start();
                        // blocked :(
            BufferedReader reader =
                    new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
            int exitCode = process.waitFor();
            System.out.println("\nExited with error code : " + exitCode);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
        
}
