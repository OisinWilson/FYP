package com.celitrackerrestapi;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import org.json.JSONException;
import org.json.simple.JSONValue;


/**
* The Event class leverages the Jersey RESTful Web Services framework to expose
* a REST API used by the Celi Tracker App to track how regularly users enters their
* diet journal. If a user leaves too much of a gap between entries the Service will
* send the user an Push Notification to remind them to keep entering their diet 
* journal in the Celi Tracker App.
* 
* Jersey RESTful Web Services framework is open source, production quality,
* framework for developing RESTful Web Services in Java that provides support 
* for JAX-RS APIs and serves as a JAX-RS (JSR 311 & JSR 339) Reference 
* Implementation. For more information on Jersey check out the following
* website https://eclipse-ee4j.github.io/jersey
*
* @author  Oisin Wilson
* @version 1.0
* @since   2020-03-25
*/

@Path("/event")
/**
 * This Jersey annotation@Path with a value of /events means the the URI to access
 * this REST API has event in it. 
 */
public class Event {
	
	/**
	 * The NotificationManager manages devices, their usages and pushes notifications
	 * to  users when required. Its a single static class. 
	 */
	static private NotificationManager notifcationManager = new NotificationManager();  

	
	
	@GET
	/**
	 * This Jersey annotation@Get is a request method designator and corresponds to 
	 * the similarly named HTTP method. The Java method annotated with this request 
	 * method designator will process HTTP GET requests. The behavior of a resource 
	 * is determined by the HTTP method to which the resource is responding.
	 */

	@Produces("application/json")
    /**
     * This Jersey annotation@Produces is used to specify the MIME media types of 
     * representations a resource can produce and send back to the client. In this case
     * it generates a JSON response. 
     */
	
	/**
	 * This is a method that uses the Jersey framework to implement a HTTP GET request
	 * that is structured as follows: 
	 * 
	 * http://localhost:8080/celitrackerrestapi/device/event?token=xxx
	 * 
	 * This HTTP GET request passes one parameter called token which is a string that
	 * stores the device token used to send Push Notifications to the App. 
	 * 
	 * This Jersey annotation@QueryParam is a type of parameter that is used to extract 
	 * values to be used by the method. Query parameters are extracted from the URI 
	 * request using this method.
	 * 
	 * @param token String which stores the Device Token used to send push notifications. 
	 * @return Response JSON response structure. Example: { "token": "xxxx", "date": "xxx"}
	 * 
	 * @throws JSONException
	 */	
	public Response update(@QueryParam("token") String token) throws JSONException 
	{
		long time = System.currentTimeMillis(); // get the current time. 
		updateDevice(token, time); // store device token and time. 
				
		// create JSON response as outlined above in the comments.
		Map<String, String> obj=new HashMap<String, String>();    
		obj.put("token",token);    
		SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd 'at' HH:mm:ss z");
		Date date = new Date(time);
		obj.put("date",formatter.format(date));   		
		String jsonResult  = JSONValue.toJSONString(obj);
		
		return Response.status(200).entity(jsonResult).build(); // return JSON response 
	}

	
	
	@GET
	/**
	 * This Jersey annotation@Get is a request method designator and corresponds to 
	 * the similarly named HTTP method. The Java method annotated with this request 
	 * method designator will process HTTP GET requests. The behavior of a resource 
	 * is determined by the HTTP method to which the resource is responding.
	 */	
	
	@Path("/time")
	/**
	 * This Jersey annotation@Path with a value of /events/time means the the URI to access
	 * this REST API has event in it. 
	 */
	
	@Produces("application/json")
	 /**
     * This Jersey annotation@Produces is used to specify the MIME media types of 
     * representations a resource can produce and send back to the client. In this case
     * it generates a JSON response. 
     */
	
	/**
	 * This is a method that uses the Jersey framework to implement a HTTP GET request
	 * that is structured as follows: 
	 * 
	 * http://localhost:8080/celitrackerrestapi/device/event/time?seconds=10
	 * 
	 * This HTTP GET request passes one parameter called time which allows us to change 
	 * the daily Push Notification time into a smaller value so we can see 
	 * PushNotifications being sent to Devices 
	 * 	  
	 * This Jersey annotation@QueryParam is a type of parameter that is used to extract 
	 * values to be used by the method. Query parameters are extracted from the URI 
	 * request using this method.
	 * 
	 * @param seconds int the seconds in which devices will be sent push notifications. 
	 * @return Response JSON response structure. Example: { "seconds": "10" }
	 * 
	 * @throws JSONException
	 */		
	public Response notifcations(@QueryParam("seconds") int seconds) throws JSONException 
	{
		// set the next time limit for when push notifications are sent to devices. 
		notifcationManager.setSecondsBeforeNotifications(seconds);
		
		// create JSON response as outlined above in the comments.
		Map<String, String> obj=new HashMap<String, String>();    
		obj.put("seconds",Integer.toString(seconds));    
		String jsonResult  = JSONValue.toJSONString(obj);
		
		return Response.status(200).entity(jsonResult).build(); // return JSON response 
	}
	
	
	
	/**
	 * This is a private method used to get all the known devices from the NotificationManager
	 * and either updates the time on existing devices or creates a new device entry. 
	 * 
	 * @param token String Device token of a device. 
	 * @param time long the current time. 
	 */
	private void updateDevice(String token, long time) {
		// this is a synchronized block used to ensure parallel URL requests dont upset 
		// the service. 
		synchronized(this){ 
			// get an array of the known devices. 
			ArrayList<Device> devices = notifcationManager.getDevices(); 
			Iterator<Device> iter = devices.iterator();
			// iterates all known devices. 
			while (iter.hasNext()) { 
				Device device = iter.next();
				if (device.getToken().equals(token)) {
					// if a known device is found update current time and leave 
					// method.
					device.setTime(time);
					return;
				}
			}
			// if this is a new device to the service, create a Device object and 
			// store it in the NotificationManager with the current time. 
			Device device = new Device(token, time);
			notifcationManager.addDevice(device);
		}
	}
}
